
This directory contains different alternative API implementations for encoders and decoders. 
Usaually you need to install some additional libraries. 