// legacy include 
#pragma once
#include "A2DPStream.h"