# Basic API

Using the A2DP Callback directly is usually much more efficient then the A2DPStream which set up an additional buffer